factor = 10.
# torso
Ls0p = 5.3/factor
Ls0w = 2.0/factor

s0h = 2.0/factor

Ls1p = 4.8/factor
Ls1w = 1.8/factor

s1h = 0.8/factor

Ls2p = 5.6/factor
Ls2w = 2.0/factor

s2h = 3.0/factor

Ls3p = 6.3/factor
Ls3w = 2.3/factor

s3h = 3.0/factor

Ls4d = 6.8/factor
Ls4w = 2.5/factor

s4h = 0.6/factor

Ls5p = 5.7/factor
Ls5w = 2.0/factor

s5h = 1.0/factor

Ls6p = 3.0/factor

s6h = 1./factor

Ls7p = 5.0/factor

s7h = 1.6/factor

# left arm
La0p = 3.0/factor

a0h = 2.0/factor

La1p = 3.0/factor

a1h = 1.5/factor

La2p = 3.0/factor

a2h = 1.0/factor

La3p = 3.0/factor

a3h = 2.0/factor

La4p = 3.0/factor
La4w = 1.0/factor

a4h = 0.5/factor

La5p = 3.0/factor
La5w = 1.0/factor

a5h = 0.6/factor

La6p = 3.0/factor
La6w = 1.0/factor

a6h = 0.6/factor

La7p = 3.0/factor
La7w = 1.0/factor

# right arm
Lb0p = 3.0/factor

b0h = 2.0/factor

Lb1p = 3.0/factor

b1h = 1.5/factor

Lb2p = 3.0/factor

b2h = 1.0/factor

Lb3p = 3.0/factor

b3h = 2.0/factor

Lb4p = 3.0/factor
Lb4w = 1.0/factor

b4h = 0.5/factor

Lb5p = 3.0/factor
Lb5w = 1.0/factor

b5h = 0.6/factor

Lb6p = 3.0/factor
Lb6w = 1.0/factor

b6h = 0.6/factor

Lb7p = 3.0/factor
Lb7w = 1.0/factor

# left leg
Lj0p = 3.0/factor

j0h = 1.0/factor

Lj1p = 2.8/factor

j1h = 2.0/factor

Lj2p = 2.6/factor

j2h = 2.0/factor

Lj3p = 2.4/factor

j3h = 1.2/factor

Lj4p = 2.2/factor

j4h = 2.7/factor

Lj5p = 2.0/factor

j5h = 0.4/factor

Lj6p = 2/factor
Lj6w = .8/factor

j6h = 0.4/factor

Lj7p = 2.0/factor

j7h = 0.5/factor

Lj8p = 2/factor
Lj8w = .8/factor

j8h = 0.5/factor

Lj9p = 2/factor
Lj9w = .8/factor

# right leg
Lk0p = 3.0/factor

k0h = 1.0/factor

Lk1p = 2.8/factor

k1h = 2.0/factor

Lk2p = 2.6/factor

k2h = 2.0/factor

Lk3p = 2.4/factor

k3h = 1.2/factor

Lk4p = 2.2/factor

k4h = 2.7/factor

Lk5p = 2.0/factor

k5h = 0.4/factor

Lk6p = 2/factor
Lk6w = .8/factor

k6h = 0.4/factor

Lk7p = 2.0/factor

k7h = 0.5/factor

Lk8p = 2/factor
Lk8w = .8/factor

k8h = 0.5/factor

Lk9p = 2/factor
Lk9w = 0.8/factor

