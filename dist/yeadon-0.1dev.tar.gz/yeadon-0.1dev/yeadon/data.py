
# torso
Ls0p = 5.3
Ls0w = 2.0

s0h = 2.5

Ls1p = 4.8
Ls1w = 1.8

s1h = 0.8

Ls2p = 5.6
Ls2w = 2.0

s2h = 3.0

Ls3p = 6.3
Ls3w = 2.3

s3h = 3.0

Ls4d = 6.8
Ls4w = 2.5

s4h = 0.6

Ls5p = 5.7
Ls5w = 2.0

s5h = 1.0

Ls6p = 3.0

s6h = 1.

Ls7p = 5.0

s7h = 1.6

# left arm
La0p = 3.0

a0h = 2.0

La1p = 3.0

a1h = 1.5

La2p = 3.0

a2h = 1.0

La3p = 3.0

a3h = 2.0

La4p = 3.0

a4h = 0.5

La5p = 3.0
La5w = 1.0

a5h = 0.6

La6p = 3.0
La6w = 1.0

a6h = 0.6

La7p = 3.0
La7w = 1.0

# right arm
Lb0p = 3.0

b0h = 2.0

Lb1p = 3.0

b1h = 1.5

Lb2p = 3.0

b2h = 1.0

Lb3p = 3.0

b3h = 2.0

Lb4p = 3.0

b4h = 0.5

Lb5p = 3.0
Lb5w = 1.0

b5h = 0.6

Lb6p = 3.0
Lb6w = 1.0

b6h = 0.6

Lb7p = 3.0
Lb7w = 1.0

# left leg
Lj0p = 3.0

j0h = 1.0

Lj1p = 2.8

j1h = 2.0

Lj2p = 2.6

j2h = 2.0

Lj3p = 2.4

j3h = 1.2

Lj4p = 2.2

j4h = 2.7

Lj5p = 2.0

j5h = 0.4

Lj6p = 2
Lj6w = .8

j6h = 0.4

Lj7p = 2.0

j7h = 0.5

Lj8p = 2
Lj8w = .8

j8h = 0.5

Lj9p = 2
Lj9w = .8

# right leg
Lk0p = 3.0

k0h = 1.0

Lk1p = 2.8

k1h = 2.0

Lk2p = 2.6

k2h = 2.0

Lk3p = 2.4

k3h = 1.2

Lk4p = 2.2

k4h = 2.7

Lk5p = 2.0

k5h = 0.4

Lk6p = 2
Lk6w = .8

k6h = 0.4

Lk7p = 2.0

k7h = 0.5

Lk8p = 2
Lk8w = .8

k8h = 0.5

Lk9p = 2
Lk9w = 0.8

