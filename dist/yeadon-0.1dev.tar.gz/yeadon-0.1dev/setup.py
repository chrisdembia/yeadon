from distutils.core import setup

setup(
    name='yeadon',
    author='Chris Dembia',
    author_email='chris530d@gmail.com',
    version='0.1dev',
    packages=['yeadon',],
    license='IDK YET',
    long_description=open('README.txt').read(),
)
